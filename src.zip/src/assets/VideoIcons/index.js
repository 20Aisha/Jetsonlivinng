export {default as FullscreenOpen} from './fullscreen-open.svg';
export {default as FullscreenClose} from './fullscreen-close.svg';
export {default as VideoPlay} from './video-play.svg';
export {default as VideoPause} from './video-pause.svg';
export {default as VideoSkipBack} from './video-backward.svg';
export {default as VideoSkipForward} from './video-forward.svg';
